@extends('layouts.front')

@section('content')

    <div class="container">

        <div class="card card-default">
            <div class="card-body">
                <h3 class="text-center"> شما به این بخش دسترسی ندارید. </h3>
            </div>
        </div>

    </div>

@stop