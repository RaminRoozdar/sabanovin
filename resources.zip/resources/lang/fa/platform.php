<?php
/**
 * Created by PhpStorm.
 * User: Ali Ghasemzadeh
 * Date: 2/15/2018
 * Time: 5:26 AM
 */

return [
    'direction' => 'rtl',
    'input-pull' => 'text-md-left'
];