@extends('layouts.front')


@section('content')

    <div class="container">
        <div class="breadcrumb-container">
            <nav aria-label="breadcrumb">
               <ol class="breadcrumb bg-white font-size-breadcrumb">
                    <li class="breadcrumb-item">
                    <a class="text-dark" href="/">خانه</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">فرم تماس با ما</li>
                </ol>
            </nav>
        </div>
        <div class="row mb-2">

            <div class="col-md-12">

            </div>
        </div>

        <div class="row justify-content-center mb-2">
            <div class="col-md-12">
                <div class="card card-default">
                    <div class="card-header">
                        وضعیت پرداخت
                    </div>

                    <div class="card-body">



                    </div>
                </div>
            </div>
        </div>
    </div>

@stop
@section('js')

@endsection
