@extends('layouts.app')



@section('content')
    

      <h2> به وب سایت صبانوین خوش آمدید.</h2>
   
          <p>Thank you</p>
          


@stop

