@extends('layouts.front')

@section('content')

    <div class="container">

            <div class="card card-default">
                <div class="card-body">
                    <h3 class="text-center"> صفحه مورد نظر پیدا نشد ... </h3>
                </div>
            </div>

        </div>


@stop