<?php

return [
    'Account' => 'حساب',
    'Item' => 'اقلام',
    'Invoice' => 'فاکتور',
    'Article' => 'مقاله',
    'Expense' => 'هزینه',
    'Income' => 'درآمد',
    'Ticket' => 'تیکت',
    'File' => 'فایل',
    'Forum' => 'انجمن',
    'Setting' => 'تنظیمات',
];