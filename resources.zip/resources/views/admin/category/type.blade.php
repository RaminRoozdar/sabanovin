{{ getCategoryType($type) }}
